Este es el README para el proyecto final de taller de API con Node.js

Víctor Gerardo Ramírez González
Efraín de Jesús Dionicio Martínez
Universidad Autónoma de Querétaro
Facultad de Informática
